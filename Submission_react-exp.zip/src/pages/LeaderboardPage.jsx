import LeaderboardList from "../components/LeaderboardList";

function LeaderboardPage() {
  return (
    <section className='board-page'>
      <LeaderboardList />
    </section>
  );
}

export default LeaderboardPage;